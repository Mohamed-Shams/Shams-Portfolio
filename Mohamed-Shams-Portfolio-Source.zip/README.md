# Mohamed Ahmed Shams — bilingual portfolio

Next.js App Router, React, TypeScript, Tailwind CSS v4, Motion, Lucide, next-intl. Complete source is in this directory.

## Run locally

Requires Node.js 20.9+ (Node 22 recommended).

```sh
npm ci
npm run dev
```

Open http://localhost:3000/en or http://localhost:3000/ar.

## Production

```sh
npm ci
npm run build
npm start
```

Vercel: import this directory as a Next.js project, use `npm run build`, retain automatic Next.js settings. Netlify: use its Next.js runtime integration and `npm run build`; do not deploy this repository as plain static HTML. Set `NEXT_PUBLIC_SITE_URL` to your final HTTPS origin before building so social metadata uses the correct domain. The fallback is the existing portfolio URL verified in the supplied CV.

Self-host on a Node server with `npm start` behind an HTTPS reverse proxy. Production output uses `.next-production`; development uses `.next-dev` to avoid Windows file-lock collisions. Standalone server deployments must copy `public` and `.next-production/static` into the corresponding standalone directory. Do not expose development mode publicly.

## Content and assets

- `src/lib/content.ts`: CV-derived bilingual project, skill, certificate and training data.
- `src/components/Portfolio.tsx`: section components, interactive filters/menu, accessible routed case studies and image gallery.
- `src/app/globals.css`: responsive reference-derived visual tokens and layout.
- `public/assets/MohamedAhmedShams_CV.pdf`: original downloadable CV.
- `docs/DESIGN.md`: reference analysis, component map, provenance and remaining differences.
- `screenshots/`: screenshots at all five requested dimensions, individual desktop sections and case studies; validation report.

All seven projects have English and Arabic detail routes. Six appear initially; View All reveals the seventh. Training courses remain distinct from certifications. Only CV-confirmed professional URLs are included. Images derived from the supplied board are illustrative; no actual project photographs are claimed. Replace the small crops with licensed high-resolution originals for publication-quality photography. The supplied primary portrait is retained.

Fonts load from Google Fonts. Default dark theme intentionally matches the reference; no light theme toggle. No analytics, forms, database or credentials are required. Contact opens the verified email address.

## Verification

`npm run build` includes TypeScript validation. Run `node validate.cjs` with the local server running to exercise all ten viewport/locale combinations, project routes, filters, project expansion, gallery, mobile menu, locale switching and PDF availability. The script uses locally installed Chrome on Windows; change executablePath for other operating systems. Screenshot review compares individual compositions rather than treating the composite reference board as a website screenshot. No numerical fidelity score is claimed.
