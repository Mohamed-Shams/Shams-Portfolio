"use client";
import { useState } from "react";
import { useLocale } from "next-intl";
import Link from "next/link";
import Image from "next/image";
import { usePathname } from "next/navigation";
import { motion, useReducedMotion } from "framer-motion";
import {
  ArrowRight,
  ArrowLeft,
  Download,
  Menu,
  X,
  Mail,
  Globe,
  Activity,
  Database,
  Radio,
  ChevronDown,
} from "lucide-react";
import {
  projects,
  skills,
  credentials,
  training,
  Localized,
} from "@/lib/content";
const cv = "/assets/MohamedAhmedShams_CV.pdf";
export function Header() {
  const locale = useLocale();
  const ar = locale === "ar";
  const path = usePathname();
  const [open, setOpen] = useState(false);
  const labels = ar
    ? [
        "الرئيسية",
        "نبذة عني",
        "المشاريع",
        "المهارات",
        "الخبرات",
        "الشهادات",
        "تواصل",
      ]
    : [
        "Home",
        "About",
        "Projects",
        "Skills",
        "Experience",
        "Certifications",
        "Contact",
      ];
  return (
    <header className="header">
      <Link
        href={`/${locale}`}
        className="brand"
        aria-label={ar ? "محمد شمس — الرئيسية" : "Mohamed Shams — Home"}
      >
        <b>MS</b>
        <small>MOHAMED SHAMS</small>
      </Link>
      <span className="brand-name">
        {ar ? "محمد أحمد شمس" : "Mohamed Ahmed Shams"}
      </span>
      <nav
        aria-label={ar ? "التنقل الرئيسي" : "Main navigation"}
        className={open ? "nav open" : "nav"}
      >
        {[
          "home",
          "about",
          "projects",
          "skills",
          "experience",
          "certifications",
          "contact",
        ].map((id, i) => (
          <Link
            key={id}
            href={`/${locale}#${id}`}
            onClick={() => setOpen(false)}
          >
            {labels[i]}
          </Link>
        ))}
      </nav>
      <div className="language" aria-label="Language">
        <Link
          href={path.replace(/^\/(en|ar)/, "/en")}
          aria-current={!ar ? "page" : undefined}
        >
          EN
        </Link>
        <Link
          href={path.replace(/^\/(en|ar)/, "/ar")}
          aria-current={ar ? "page" : undefined}
        >
          AR
        </Link>
      </div>
      <a href={`/${locale}#contact`} className="button small header-contact">
        {ar ? "تواصل معي" : "Get in Touch"}
      </a>
      <button
        className="menu"
        onClick={() => setOpen(!open)}
        aria-expanded={open}
        aria-label={
          ar
            ? open
              ? "إغلاق القائمة"
              : "فتح القائمة"
            : open
              ? "Close menu"
              : "Open menu"
        }
      >
        {open ? <X /> : <Menu />}
      </button>
    </header>
  );
}
function Eyebrow({ children }: { children: React.ReactNode }) {
  return <div className="eyebrow">{children}</div>;
}
export function GlobeArt() {
  return (
    <svg
      className="globe-art"
      viewBox="0 0 480 480"
      fill="none"
      aria-hidden="true"
    >
      <defs>
        <radialGradient id="glow">
          <stop stopColor="#1376a4" stopOpacity=".22" />
          <stop offset="1" stopColor="#080d12" stopOpacity="0" />
        </radialGradient>
      </defs>
      <circle cx="240" cy="240" r="230" fill="url(#glow)" />
      <g stroke="#1688b5" strokeWidth=".7" opacity=".65">
        <circle cx="240" cy="240" r="190" />
        {[40, 85, 135, 175].map((r) => (
          <ellipse
            key={r}
            cx="240"
            cy="240"
            rx={r}
            ry="190"
            transform="rotate(-25 240 240)"
          />
        ))}
        {[-120, -60, 0, 60, 120].map((y) => (
          <ellipse
            key={y}
            cx="240"
            cy={240 + y}
            rx={Math.sqrt(190 * 190 - y * y)}
            ry="38"
            transform="rotate(-25 240 240)"
          />
        ))}
        <path d="M120 115 190 165 300 105 355 190 280 265 385 315 265 405 190 320 110 345 80 230 190 165 280 265 190 320 355 190M110 345 280 265 300 105" />
      </g>
      {[
        [120, 115],
        [190, 165],
        [300, 105],
        [355, 190],
        [280, 265],
        [385, 315],
        [265, 405],
        [190, 320],
        [110, 345],
        [80, 230],
      ].map(([x, y], i) => (
        <g key={i}>
          <circle cx={x} cy={y} r="8" fill="#f1a342" opacity=".1" />
          <circle cx={x} cy={y} r="2.6" fill="#f1a342" />
        </g>
      ))}
      <path
        d="M287 148c-18-26-23-31-23-41a23 23 0 0146 0c0 10-6 18-23 41Z"
        fill="#f1a342"
      />
      <circle cx="287" cy="107" r="8" fill="#101820" />
    </svg>
  );
}
function Scada() {
  return (
    <div className="scada" aria-hidden="true">
      <div>
        <span>SCADA</span>
        <Activity size={16} />
      </div>
      <svg viewBox="0 0 240 120">
        <defs>
          <pattern
            id="grid"
            width="24"
            height="20"
            patternUnits="userSpaceOnUse"
          >
            <path
              d="M24 0H0V20"
              fill="none"
              stroke="#1688b5"
              strokeWidth=".5"
            />
          </pattern>
        </defs>
        <rect width="240" height="120" fill="url(#grid)" />
        <path
          d="M0 102 27 90 44 95 64 55 87 69 111 39 140 55 172 19 192 32 231 5"
          fill="none"
          stroke="#32baf0"
          strokeWidth="2"
        />
      </svg>
      <small>IIoT · DATA · AUTOMATION</small>
    </div>
  );
}
export default function Portfolio() {
  const locale = useLocale() as "en" | "ar";
  const ar = locale === "ar";
  const t = (en: string, arabic: string) => (ar ? arabic : en);
  const tx = (v: Localized) => v[locale];
  const [category, setCategory] = useState("All");
  const [all, setAll] = useState(false);
  const reduced = useReducedMotion();
  return (
    <>
      <a className="skip-link" href="#main">
        {t("Skip to content", "انتقل إلى المحتوى")}
      </a>
      <Header />
      <main id="main">
        <section className="hero" id="home">
          <div className="hero-portrait">
            <Image
              src="/assets/portrait.webp"
              alt={t("Mohamed Ahmed Shams", "محمد أحمد شمس")}
              fill
              priority
              sizes="(max-width: 700px) 100vw, 75vw"
            />
          </div>
          <div className="industrial" />
          <div className="hero-shade" />
          <Scada />
          <motion.div
            className="hero-copy"
            initial={reduced ? false : { opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <Eyebrow>{t("Systems Engineer", "مهندس أنظمة")}</Eyebrow>
            <h1>
              {ar ? (
                <>محمد أحمد شمس</>
              ) : (
                <>
                  Mohamed <br />
                  Ahmed Shams
                </>
              )}
            </h1>
            <h2>
              {t("Engineering Intelligent", "أطوّر أنظمة صناعية ذكية")}
              <br />
              {t("Industrial Systems.", "تربط الواقع بالتكنولوجيا.")}
            </h2>
            <p className="roles">
              {t(
                "SCADA Developer | Industrial IoT Engineer | Systems Engineer",
                "مهندس أنظمة | مطوّر SCADA | متخصص إنترنت الأشياء الصناعي",
              )}
            </p>
            <p className="hero-description">
              {t(
                "I design, develop, and integrate intelligent industrial platforms — connecting real-world operations with reliable software, data, and modern digital technologies.",
                "أصمم وأطور وأكامل منصات صناعية ذكية تربط العمليات الفعلية بالمستشعرات والبيانات وأحدث التقنيات الرقمية.",
              )}
            </p>
            <div className="actions">
              <a className="button" href="#projects">
                {t("Explore My Work", "استكشف أعمالي")}
                <ArrowRight size={17} />
              </a>
              <a className="button outline" href={cv} download>
                {t("Download CV", "تحميل السيرة الذاتية")}
                <Download size={17} />
              </a>
            </div>
          </motion.div>
          <div className="micro">
            REAL OPERATIONS
            <br />
            REAL DATA
            <br />
            SMARTER SOLUTIONS
          </div>
          <a href="#about" className="scroll">
            {t("Scroll", "اكتشف")}
            <ChevronDown size={15} />
          </a>
          <svg
            className="signal-lines"
            viewBox="0 0 1000 180"
            preserveAspectRatio="none"
            aria-hidden="true"
          >
            {[0, 12, 25, 38].map((y) => (
              <path
                key={y}
                d={`M0 ${80 + y} C220 ${5 + y},230 ${180 + y},480 ${95 + y} S700 ${15 + y},1000 ${140 + y}`}
                stroke="#1688b5"
                fill="none"
                strokeWidth=".8"
              />
            ))}
          </svg>
        </section>
        <section id="about" className="section about">
          <div className="about-copy">
            <Eyebrow>{t("About me", "نبذة عني")}</Eyebrow>
            <h2>
              {t("From Industrial", "من الأنظمة الصناعية")}
              <br />
              {t("Systems to Smarter", "إلى حلول أكثر")}
              <br />
              {t("Solutions.", "ذكاءً.")}
            </h2>
            <p>
              {t(
                "I’m a Systems Engineer at pulse by solutions with hands-on experience in SCADA, Industrial IoT, and digital transformation projects across Egypt and Saudi Arabia. I enjoy building reliable, scalable systems that turn real-world data into meaningful insights and smarter operations.",
                "أنا مهندس أنظمة لدى pulse by solutions، ولدي خبرة عملية في SCADA وإنترنت الأشياء الصناعي ومشروعات التحول الرقمي في مصر والسعودية. أعمل على بناء أنظمة موثوقة وقابلة للتوسع تحوّل بيانات الواقع إلى رؤى مفيدة وعمليات أكثر ذكاءً.",
              )}
            </p>
            <div className="signature">Mohamed Shams</div>
          </div>
          <div className="about-image">
            <Image
              src="/assets/about.webp"
              alt={t(
                "Monochrome portrait from the supplied design reference",
                "صورة أحادية اللون من المرجع التصميمي المقدم",
              )}
              fill
              sizes="(max-width:700px) 80vw, 35vw"
            />
            <div className="statement">
              {t("Turning", "تحويل")}
              <br />
              {t("Industrial Data", "البيانات الصناعية")}
              <br />
              {t("Into Real Impact.", "إلى أثر حقيقي.")}
            </div>
          </div>
          <div className="stats">
            {[
              ["7K+", t("Underground Wells", "بئر مياه جوفية")],
              [
                "10K+",
                t("Industrial Sensors (POC)", "حساس صناعي (إثبات مفهوم)"),
              ],
              ["1.3K+", t("Drilling Equipment Assets", "أصل من معدات الحفر")],
            ].map(([n, label]) => (
              <div key={n}>
                <strong>{n}</strong>
                <span>{label}</span>
              </div>
            ))}
            <p>
              {t(
                "Scale of projects I contributed to as part of a team.",
                "نطاق المشروعات التي ساهمت فيها ضمن فريق عمل.",
              )}
            </p>
          </div>
        </section>
        <section id="projects" className="section">
          <div className="section-heading">
            <div>
              <Eyebrow>{t("Featured projects", "مشاريع مختارة")}</Eyebrow>
              <h2>{t("Selected Work", "أعمال مختارة")}</h2>
              <p>
                {t(
                  "A selection of industrial and government projects I’ve contributed to.",
                  "مجموعة من المشروعات الصناعية والحكومية التي ساهمت فيها.",
                )}
              </p>
            </div>
            <button
              className="text-link"
              onClick={() => setAll(!all)}
              aria-expanded={all}
            >
              {all
                ? t("Show featured", "عرض المختارة")
                : t("View All Projects", "عرض جميع المشاريع")}
              <ArrowRight size={16} />
            </button>
          </div>
          <div className="projects-grid">
            {projects.slice(0, all ? 7 : 6).map((p) => (
              <Link
                className="project-card"
                key={p.slug}
                href={`/${locale}/projects/${p.slug}`}
              >
                <div className="card-image">
                  <Image
                    src={`/assets/${p.image}.webp`}
                    alt=""
                    fill
                    sizes="(max-width:700px) 90vw, 33vw"
                  />
                  <span className="image-label">
                    {t("Illustrative image", "صورة توضيحية")}
                  </span>
                </div>
                <div className="card-copy">
                  <h3>{tx(p.title)}</h3>
                  <span className="circle-arrow">
                    <ArrowRight size={17} />
                  </span>
                  <p>{tx(p.sector)}</p>
                  <div className="tags">
                    {p.tags.slice(0, 3).map((tag) => (
                      <span key={tag}>{tag}</span>
                    ))}
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </section>
        <section id="skills" className="section">
          <div className="tech-panel">
            <Eyebrow>{t("Technical expertise", "الخبرات التقنية")}</Eyebrow>
            <h2>{t("Tools & Technologies", "الأدوات والتقنيات")}</h2>
            <p>
              {t(
                "The technologies and tools I work with to build industrial and digital solutions.",
                "التقنيات والأدوات التي أستخدمها لبناء الحلول الصناعية والرقمية.",
              )}
            </p>
            <div className="filters">
              {[
                "All",
                "Industrial Platforms",
                "Connectivity",
                "Programming",
                "Databases",
                "Tools & AI",
              ].map((c, i) => (
                <button
                  key={c}
                  aria-pressed={category === c}
                  onClick={() => setCategory(c)}
                  className={category === c ? "active" : ""}
                >
                  {ar
                    ? [
                        "الكل",
                        "المنصات الصناعية",
                        "الاتصال",
                        "البرمجة",
                        "قواعد البيانات",
                        "الأدوات والذكاء الاصطناعي",
                      ][i]
                    : c}
                </button>
              ))}
            </div>
            <div className="skills-grid">
              {skills
                .filter((s) => category === "All" || s[3] === category)
                .map((s, i) => (
                  <div className="skill-tile" key={s[0]}>
                    <span className={`tech-symbol symbol-${i % 5}`}>
                      {s[4]}
                    </span>
                    <div>
                      <h3>{s[0]}</h3>
                      <small>{s[ar ? 2 : 1]}</small>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        </section>
        <section id="experience" className="section journey">
          <Eyebrow>{t("Professional experience", "الخبرة المهنية")}</Eyebrow>
          <h2>{t("My Journey", "مسيرتي المهنية")}</h2>
          <p>
            {t(
              "Key projects and responsibilities throughout my career.",
              "أبرز المشروعات والمسؤوليات خلال مسيرتي المهنية.",
            )}
          </p>
          <div className="timeline">
            <div className="employer">
              pulse<small>by solutions</small>
            </div>
            <div className="career">
              <div className="career-title">
                <div>
                  <h3>{t("Systems Engineer", "مهندس أنظمة")}</h3>
                  <span>pulse by solutions</span>
                </div>
                <time>{t("Sep 2024 – Present", "سبتمبر 2024 – حتى الآن")}</time>
              </div>
              <ul>
                {projects.map((p) => (
                  <li key={p.slug}>
                    <Link href={`/${locale}/projects/${p.slug}`}>
                      {tx(p.title)}
                    </Link>
                    <span dir="ltr">
                      {ar ? p.date.replace("Present", "حتى الآن") : p.date}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
          <div className="education">
            <span>{t("Education", "التعليم")}</span>
            <p>
              {t(
                "B.Sc., Electrical Engineering · Menoufia University · July 2024",
                "بكالوريوس الهندسة الكهربائية · جامعة المنوفية · يوليو 2024",
              )}
            </p>
            <p>
              {t(
                "Arabic: Native · English: Very good",
                "العربية: اللغة الأم · الإنجليزية: جيد جدًا",
              )}
            </p>
          </div>
        </section>
        <section id="certifications" className="section">
          <Eyebrow>{t("Certifications", "الشهادات")}</Eyebrow>
          <h2>{t("Continuous Learning", "تعلّم مستمر")}</h2>
          <p>
            {t(
              "Professional certifications and key training courses.",
              "شهادات مهنية ودورات تدريبية متخصصة.",
            )}
          </p>
          <div className="cert-grid">
            {[...credentials, [...training[0], "SIEMENS"]].map((c) => (
              <article className="cert-card" key={c[0]}>
                <div className={`cert-brand ${c[4]?.toLowerCase()}`}>
                  {c[4]}
                </div>
                <div>
                  <h3>{c[ar ? 1 : 0]}</h3>
                  <p>{c[2]}</p>
                  <time>{c[3]}</time>
                  {c[4] === "SIEMENS" && (
                    <small>{t("Training course", "دورة تدريبية")}</small>
                  )}
                </div>
              </article>
            ))}
          </div>
          <details className="training">
            <summary>
              {t(
                "All additional training courses",
                "جميع الدورات التدريبية الإضافية",
              )}
            </summary>
            <div className="cert-grid">
              {training.slice(1).map((c) => (
                <article className="cert-card" key={c[0]}>
                  <div>
                    <h3>{c[ar ? 1 : 0]}</h3>
                    <p>{c[2]}</p>
                    <time>{c[3]}</time>
                  </div>
                </article>
              ))}
            </div>
          </details>
        </section>
        <section id="contact" className="section contact">
          <div className="contact-copy">
            <Eyebrow>{t("Contact", "تواصل معي")}</Eyebrow>
            <h2>
              {t(
                "Let’s Build Something Intelligent.",
                "لنصنع معًا حلولًا أكثر ذكاءً.",
              )}
            </h2>
            <h3 lang="ar" dir="rtl">
              خلينا نبني حاجة ذكية مع بعض
            </h3>
            <p>
              {t(
                "I’m always open to discussing new opportunities, interesting projects, or ideas related to SCADA, IIoT, and industrial systems.",
                "يسعدني مناقشة الفرص الجديدة والمشروعات والأفكار المتعلقة بأنظمة SCADA وإنترنت الأشياء الصناعي والأنظمة الصناعية.",
              )}
            </p>
            <a href="mailto:mohamed.ah.shams@gmail.com">
              <Mail size={19} />
              <span dir="ltr">mohamed.ah.shams@gmail.com</span>
            </a>
            <a
              href="https://mohamed-shams.netlify.app/"
              target="_blank"
              rel="noreferrer"
            >
              <Globe size={19} />
              {t("Professional portfolio", "الموقع المهني")}
            </a>
            <a href={cv} download className="button outline">
              {t("Download CV", "تحميل السيرة الذاتية")}
              <Download size={17} />
            </a>
          </div>
          <GlobeArt />
        </section>
      </main>
      <footer>
        <Link href={`/${locale}`} className="brand">
          <b>MS</b>
        </Link>
        <span>
          © {new Date().getFullYear()}{" "}
          {t("Mohamed Ahmed Shams", "محمد أحمد شمس")}
        </span>
        <a href="#home">{t("Back to top ↑", "العودة للأعلى ↑")}</a>
      </footer>
    </>
  );
}
export function CaseStudy({ slug }: { slug: string }) {
  const locale = useLocale() as "ar" | "en";
  const ar = locale === "ar";
  const p = projects.find((p) => p.slug === slug)!;
  const [photo, setPhoto] = useState(p.image);
  const t = (a: string, b: string) => (ar ? b : a);
  return (
    <>
      <Header />
      <main className="case section">
        <Link className="back-link" href={`/${locale}#projects`}>
          <ArrowLeft size={16} />
          {t("Back to Projects", "العودة للمشاريع")}
        </Link>
        <div className="case-heading">
          <div>
            <Eyebrow>{t("Project case study", "دراسة حالة")}</Eyebrow>
            <h1>{p.title[locale]}</h1>
            <div className="tags">
              {p.tags.map((tag) => (
                <span key={tag}>{tag}</span>
              ))}
            </div>
          </div>
          <p dir="ltr">
            {p.date}
            <br />
            {p.sector[locale]}
          </p>
        </div>
        <div className="case-grid">
          <div>
            <div className="case-photo">
              <Image
                src={`/assets/${photo}.webp`}
                alt={t(
                  "Illustrative industrial scene from the supplied design reference; not an actual project photograph.",
                  "مشهد صناعي توضيحي من المرجع التصميمي المقدم، وليس صورة فعلية للمشروع.",
                )}
                fill
                priority
                sizes="(max-width:700px) 90vw, 55vw"
              />
            </div>
            <p className="caption">
              {t(
                "Reference imagery · Illustrative, not actual project photography",
                "صور مرجعية توضيحية · ليست صورًا فعلية للمشروع",
              )}
            </p>
            <div className="thumbnails">
              {[p.image, "plant", "city"].map((img, i) => (
                <button
                  key={i}
                  aria-label={`${t("View image", "عرض الصورة")} ${i + 1}`}
                  aria-pressed={photo === img}
                  onClick={() => setPhoto(img)}
                >
                  <Image
                    src={`/assets/${img}.webp`}
                    alt=""
                    fill
                    sizes="160px"
                  />
                </button>
              ))}
            </div>
          </div>
          <div className="case-text">
            <h2>{t("Project Overview", "نظرة عامة")}</h2>
            <p>{p.overview[locale]}</p>
            <h2>{t("My Responsibilities", "مسؤولياتي")}</h2>
            <ul>
              {p.responsibilities.map((r, i) => (
                <li key={i}>{r[locale]}</li>
              ))}
            </ul>
            <h2>{t("Key Technologies", "التقنيات الرئيسية")}</h2>
            <div className="case-tools">
              {p.tags.map((tag, i) => (
                <div key={tag}>
                  {i % 3 === 0 ? (
                    <Activity />
                  ) : i % 3 === 1 ? (
                    <Database />
                  ) : (
                    <Radio />
                  )}
                  <span>{tag}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
        <div className="next-project">
          <Link
            className="text-link"
            href={`/${locale}/projects/${projects[(projects.indexOf(p) + 1) % projects.length].slug}`}
          >
            {t("Next project", "المشروع التالي")}
            <ArrowRight size={18} />
          </Link>
        </div>
      </main>
    </>
  );
}
