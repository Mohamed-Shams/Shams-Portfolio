import { getRequestConfig } from "next-intl/server";
export default getRequestConfig(async () => ({
  locale: "en",
  messages: {},
  timeZone: "Africa/Cairo",
}));
